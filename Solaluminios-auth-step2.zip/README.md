# Solaluminios: usuarios y autenticación

## Qué incorpora

- Inicio de sesión mediante correo y contraseña, con JWT de una hora.
- Consulta del usuario autenticado.
- Creación, listado y activación/desactivación de usuarios por administradores.
- Autenticación global: las rutas existentes requieren un token.
- Lecturas existentes para usuarios autenticados; escrituras existentes solo
  para ADMIN, hasta asignar explícitamente los permisos de los módulos nuevos.
- Las contraseñas se guardan con scrypt y un salt aleatorio; no se exponen hashes.
- El guard consulta el estado y rol actual del usuario en cada solicitud.
- Límite de cinco solicitudes por minuto por IP al endpoint de login. Incluye
  solicitudes correctas e incorrectas. Los contadores de esta etapa son locales
  a la instancia del proceso.

No hay registro público de usuarios. No modifica schema.prisma ni requiere una
migración: utiliza la tabla users que ya creamos.

## 1. Copiar archivos

Copia la carpeta apps del paquete dentro de la raíz Aduvidrios. Contiene solo
archivos nuevos en apps/api/src/modules/auth, apps/api/src/modules/users,
apps/api/src/infrastructure/security, apps/api/src/scripts y apps/api/scripts.
Conserva los módulos, controladores y servicios existentes.

## 2. Instalar dependencias

Desde apps/api:

```powershell
pnpm add @nestjs/jwt @nestjs/throttler
pnpm add -D tsx
```

Conserva Prisma y sus paquetes en 7.8.0. Ya necesitas class-validator,
class-transformer y dotenv instalados. El helper de contraseñas utiliza
node:crypto, sin instalaciones nativas adicionales.

## 3. Registrar los módulos

En src/app.module.ts añade:

```ts
import { AuthModule } from './modules/auth/auth.module.js';
import { UsersModule } from './modules/users/users.module.js';
```

Agrega AuthModule y UsersModule al arreglo imports, conservando DatabaseModule,
CatalogModule y LocationsModule. Ejemplo:

```ts
imports: [DatabaseModule, AuthModule, CatalogModule, LocationsModule, UsersModule],
```

Conserva el ValidationPipe global y `import 'dotenv/config'` de main.ts.
No registres otra vez los guards: AuthModule ya los registra con APP_GUARD.

## 4. Configurar el secreto de JWT

Desde apps/api:

```powershell
node .\scripts\Configure-Jwt.mjs
```

El script agrega JWT_SECRET a tu .env con un valor aleatorio. No imprime su
valor ni reemplaza uno existente. Si existe uno demasiado corto, falla para
que puedas corregirlo. La aplicación lee ese secreto al iniciar.
No copies tu .env al frontend ni lo incluyas en el repositorio.

## 5. Generar y compilar

```powershell
pnpm exec prisma generate
pnpm run build
```

## 6. Crear el primer administrador

Desde apps/api:

```powershell
& .\scripts\Create-Admin.ps1
```

Si Windows bloquea el script, puedes usar una política temporal para el proceso:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Create-Admin.ps1
```

Te pedirá nombre, correo y contraseña (12 a 128 caracteres). La contraseña no
se muestra y no se guarda en .env. Las variables temporales se eliminan al
finalizar. No crea otro administrador si ya existe uno, no altera cuentas
existentes y no resetea contraseñas. Para otras cuentas se utiliza POST /users.
Ejecuta este bootstrap una sola vez, contra la base local solaluminios_dev.

El bootstrap usa Prisma directamente con el adapter PostgreSQL; no depende
del proceso HTTP ni de los guards. tsx se utiliza exclusivamente para este
script, no para iniciar NestJS.

## 7. Iniciar el API

```powershell
pnpm run start:dev
```

Las rutas anteriores, incluido /health/database, ahora devuelven 401 si no
envías un token. Eso es esperado. No hace falta marcarlas públicas para las
pruebas. El script Test-Auth envía el token en el header Authorization.

## 8. Pruebas

En otra consola, desde apps/api:

```powershell
& .\scripts\Test-Auth.ps1
```

Alternativa si está bloqueado:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Test-Auth.ps1
```

Te pedirá las credenciales del administrador, sin mostrar contraseña o tokens.
Verifica:

| Caso | Resultado |
| --- | --- |
| Consulta sin token | 401 |
| Token inválido | 401 |
| Login correcto | 200 y token |
| GET /auth/me | Usuario correcto sin hash |
| Catálogos, ubicaciones y health con sesión | 200 |
| Contraseña incorrecta | 401 |
| Administrador crea usuario READ_ONLY | 201 |
| Correo duplicado | 409 |
| Contraseña de creación demasiado corta | 400 |
| READ_ONLY consulta ubicaciones | 200 |
| READ_ONLY lista usuarios | 403 |
| READ_ONLY intenta crear ubicación | 403 |
| READ_ONLY intenta desactivar usuario | 403 |
| Administrador intenta desactivarse a sí mismo | 400 |
| Administrador desactiva usuario de prueba | 200 |
| Token emitido antes de desactivar ese usuario | 401 |
| Login de usuario inactivo | 401 |
| Respuestas de usuarios | Sin password ni passwordHash |

La prueba deja un usuario de prueba inactivo con correo único por ejecución.
No duplica ubicaciones ni modifica el administrador. No es necesario repetir
si pasó. Si aparece 429, espera al menos un minuto antes de reintentar: el
endpoint login limita solicitudes por IP, incluso si son válidas.

El antiguo Test-Locations.ps1 no envía token; tras activar autenticación sus
solicitudes recibirán 401. No interpretes eso como un fallo de ubicaciones.

## Endpoints

| Método | Ruta | Acceso |
| --- | --- | --- |
| POST | /auth/login | Público, limitado por frecuencia |
| GET | /auth/me | Autenticado |
| GET | /users | ADMIN |
| POST | /users | ADMIN |
| PATCH | /users/:id/active | ADMIN |

POST /users recibe name, email, password y role. Roles: ADMIN, WAREHOUSE,
SALES y READ_ONLY. Si omites role, utiliza READ_ONLY. PATCH recibe solo active.
No existe todavía edición de rol, ubicación predeterminada o contraseña.

Authorization debe ser `Bearer <access_token>` en las rutas protegidas.
Para permisos explícitos de nuevos módulos usa el decorador Roles del paquete,
por ejemplo @Roles('ADMIN', 'WAREHOUSE') en los endpoints de inventario.

## Pruebas efectuadas al preparar el paquete

El helper real de contraseñas se ejecutó en Node.js y pasó generación y
verificación, salts diferentes, contraseña Unicode, contraseña incorrecta y
rechazo de hashes malformados. La compilación NestJS y las pruebas HTTP deben
ejecutarse en tu proyecto Windows: no tenemos su instalación ni su PostgreSQL.

No se incorporan refresh tokens ni cierre de sesión con lista de revocación.
El token vence a la hora. Desactivar la cuenta bloquea también sus tokens
vigentes porque se consulta la cuenta en cada solicitud. El frontend se
implementará después de confirmar estas pruebas.
